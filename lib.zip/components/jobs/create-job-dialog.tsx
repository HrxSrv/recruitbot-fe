"use client"

import * as React from "react"
import { motion } from "framer-motion"
import { Grip, Plus, Upload, X } from "lucide-react"
import { useCallback, useState } from "react"

import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Textarea } from "@/components/ui/textarea"
import { cn } from "@/lib/utils"

type Criterion = {
  id: string
  text: string
}

type Question = {
  id: string
  text: string
  idealAnswer: string
  required: boolean
}

type JobFormData = {
  title: string
  description: string
  criteria: Criterion[]
  questions: Question[]
  files: File[]
}

const steps = [
  { id: 1, name: "Details" },
  { id: 2, name: "Criteria" },
  { id: 3, name: "Questions" },
  { id: 4, name: "Upload" },
]

export function CreateJobDialog({
  open,
  onOpenChange,
}: {
  open: boolean
  onOpenChange: (open: boolean) => void
}) {
  const [currentStep, setCurrentStep] = useState(1)
  const [formData, setFormData] = useState<JobFormData>({
    title: "",
    description: "",
    criteria: [],
    questions: [],
    files: [],
  })

  const handleNext = () => {
    if (currentStep < 4) {
      setCurrentStep((prev) => prev + 1)
    }
  }

  const handlePrevious = () => {
    if (currentStep > 1) {
      setCurrentStep((prev) => prev - 1)
    }
  }

  const addCriterion = () => {
    setFormData((prev) => ({
      ...prev,
      criteria: [...prev.criteria, { id: crypto.randomUUID(), text: "" }],
    }))
  }

  const removeCriterion = (id: string) => {
    setFormData((prev) => ({
      ...prev,
      criteria: prev.criteria.filter((c) => c.id !== id),
    }))
  }

  const updateCriterion = (id: string, text: string) => {
    setFormData((prev) => ({
      ...prev,
      criteria: prev.criteria.map((c) => (c.id === id ? { ...c, text } : c)),
    }))
  }

  const addQuestion = () => {
    setFormData((prev) => ({
      ...prev,
      questions: [
        ...prev.questions,
        { id: crypto.randomUUID(), text: "", idealAnswer: "", required: false },
      ],
    }))
  }

  const removeQuestion = (id: string) => {
    setFormData((prev) => ({
      ...prev,
      questions: prev.questions.filter((q) => q.id !== id),
    }))
  }

  const updateQuestion = (id: string, updates: Partial<Question>) => {
    setFormData((prev) => ({
      ...prev,
      questions: prev.questions.map((q) =>
        q.id === id ? { ...q, ...updates } : q
      ),
    }))
  }

  const onDrop = useCallback((acceptedFiles: File[]) => {
    setFormData((prev) => ({
      ...prev,
      files: [...prev.files, ...acceptedFiles],
    }))
  }, [])

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] flex flex-col gap-4 p-6">
        <DialogHeader className="flex-none">
          <DialogTitle className="text-2xl">Create New Job</DialogTitle>
          <DialogDescription>
            Fill out the job details in this multi-step form
          </DialogDescription>
        </DialogHeader>

        {/* Progress Steps */}
        <div className="relative mb-8 mt-2 flex-none">
          <div className="relative flex justify-between">
            {steps.map((step, index) => (
              <div
                key={step.id}
                className={cn("flex flex-col items-center gap-2 relative", {
                  "text-primary": currentStep === step.id,
                  "text-muted-foreground": currentStep !== step.id,
                })}
              >
                {/* Progress line */}                {index < steps.length - 1 && (
                  <div
                    className={cn(
                      "absolute left-[calc(50%+12px)] w-[170px] right-[calc(-50%+12px)] top-4 h-px -translate-y-1/2 bg-border transition-colors duration-200",
                      {
                        "bg-primary": currentStep > step.id,
                      }
                    )}
                  />
                )}
                <div
                  className={cn(
                    "relative z-10 flex h-8 w-8 items-center justify-center rounded-full border text-sm font-medium transition-colors duration-200",
                    {
                      "border-primary bg-primary text-primary-foreground":
                        currentStep === step.id,
                      "border-muted-foreground bg-background":
                        currentStep !== step.id,
                      "border-green-500 bg-green-500 text-white":
                        currentStep > step.id,
                    }
                  )}
                >
                  {currentStep > step.id ? "✓" : step.id}
                </div>
                <span className="text-sm font-medium">{step.name}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Form Steps */}
        <div className="flex-1 min-h-0 overflow-y-auto px-1">
          {currentStep === 1 && (
            <div className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="title">Job Title</Label>
                <Input
                  id="title"
                  placeholder="e.g., Senior Frontend Developer"
                  value={formData.title}
                  onChange={(e) =>
                    setFormData((prev) => ({ ...prev, title: e.target.value }))
                  }
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="description">Job Description</Label>
                <Textarea
                  id="description"
                  placeholder="Enter the job description..."
                  className="min-h-[120px]"
                  value={formData.description}
                  onChange={(e) =>
                    setFormData((prev) => ({
                      ...prev,
                      description: e.target.value,
                    }))
                  }
                />
              </div>
            </div>
          )}

          {currentStep === 2 && (
            <div className="space-y-4">
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={addCriterion}
              >
                <Plus className="mr-2 h-4 w-4" />
                Add Criterion
              </Button>
              <div className="space-y-4">
                {formData.criteria.map((criterion) => (
                  <div
                    key={criterion.id}
                    className="flex items-center gap-2 rounded-md border p-2"
                  >
                    <Grip className="h-5 w-5 text-muted-foreground" />
                    <Input
                      placeholder="Enter criterion"
                      value={criterion.text}
                      onChange={(e) =>
                        updateCriterion(criterion.id, e.target.value)
                      }
                    />
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => removeCriterion(criterion.id)}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {currentStep === 3 && (
            <div className="space-y-4">
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={addQuestion}
              >
                <Plus className="mr-2 h-4 w-4" />
                Add Question
              </Button>
              <div className="space-y-6">
                {formData.questions.map((question) => (
                  <div
                    key={question.id}
                    className="space-y-4 rounded-lg border p-4"
                  >
                    <div className="flex justify-between">
                      <Label>Question</Label>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeQuestion(question.id)}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                    <Input
                      placeholder="Enter question"
                      value={question.text}
                      onChange={(e) =>
                        updateQuestion(question.id, { text: e.target.value })
                      }
                    />
                    <div className="space-y-2">
                      <Label>Ideal Answer</Label>
                      <Textarea
                        placeholder="Enter ideal answer"
                        value={question.idealAnswer}
                        onChange={(e) =>
                          updateQuestion(question.id, {
                            idealAnswer: e.target.value,
                          })
                        }
                      />
                    </div>
                    <div className="flex items-center gap-2">
                      <Switch
                        id={`required-${question.id}`}
                        checked={question.required}
                        onCheckedChange={(checked) =>
                          updateQuestion(question.id, { required: checked })
                        }
                      />
                      <Label htmlFor={`required-${question.id}`}>Required</Label>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {currentStep === 4 && (
            <div className="space-y-4">
              <div
                className="flex h-[200px] cursor-pointer flex-col items-center justify-center rounded-lg border-2 border-dashed text-center hover:bg-muted/50"
                onDragOver={(e) => e.preventDefault()}
                onDrop={(e) => {
                  e.preventDefault()
                  const files = Array.from(e.dataTransfer.files)
                  onDrop(files)
                }}
                onClick={() => {
                  const input = document.createElement("input")
                  input.type = "file"
                  input.multiple = true
                  input.accept = ".pdf,.doc,.docx"
                  input.onchange = (e) => {
                    const files = Array.from(
                      (e.target as HTMLInputElement).files || []
                    )
                    onDrop(files)
                  }
                  input.click()
                }}
              >
                <Upload className="mb-4 h-10 w-10 text-muted-foreground" />
                <div className="space-y-2">
                  <p className="text-sm font-medium">
                    Drop resumes here or click to browse
                  </p>
                  <p className="text-sm text-muted-foreground">
                    Accepts PDF, DOC, and DOCX files
                  </p>
                </div>
              </div>

              {formData.files.length > 0 && (
                <div className="space-y-2">
                  <Label>Uploaded Files</Label>
                  <div className="space-y-2 rounded-lg border p-4">
                    {formData.files.map((file, index) => (
                      <div
                        key={index}
                        className="flex items-center justify-between rounded-md bg-muted/50 p-2 text-sm"
                      >
                        <span>{file.name}</span>
                        <span className="text-muted-foreground">
                          {(file.size / 1024 / 1024).toFixed(2)} MB
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Navigation Buttons */}
        <div className="flex justify-between pt-4 flex-none border-t">
          <Button
            variant="outline"
            size="lg"
            onClick={handlePrevious}
            disabled={currentStep === 1}
            className="min-w-[100px] transition-all duration-200 hover:bg-primary/5"
          >
            Previous
          </Button>
          <Button
            size="lg"
            onClick={currentStep === 4 ? () => {} : handleNext}
            disabled={
              (currentStep === 1 && !formData.title) ||
              (currentStep === 4 && formData.files.length === 0)
            }
            className="min-w-[100px] transition-all duration-200"
          >
            {currentStep === 4 ? "Create Job" : "Next"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
