"use client"

import { useParams, useRouter } from "next/navigation"
import { ArrowLeft, Briefcase, Calendar, Clock, DollarSign, MapPin, Users } from "lucide-react"
import { motion } from "framer-motion"

import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { PencilIcon, Trash2Icon } from "lucide-react"

// Example job data structure matching the DB schema
const jobsData = [
	{
		id: 1,
		title: "Senior Python Developer",
		department: "Engineering",
		location: "San Francisco, CA",
		job_type: "full_time",
		status: "active",
		application_count: 0,
		view_count: 0,
		created_by: "68440168f54c9e0e2a688ef9",
		customer_id: "68440168f54c9e0e2a688ef8",
		description: "We are looking for an experienced Python developer to join our team.",
		experience_level: "senior",
		remote_allowed: true,
		requirements: [
			"5+ years of experience with Python",
			"Experience with Django or Flask",
			"Strong understanding of RESTful APIs",
			"Experience with cloud platforms (AWS/GCP)",
			"Excellent problem-solving skills",
		],
		salary_range: {
			min: 120000,
			max: 180000,
			currency: "USD",
		},
		application_deadline: "2025-07-07T14:37:53.672+00:00",
	},
]

export default function JobDetailsPage() {
	const params = useParams()
	const router = useRouter()
	const jobId = Number(params.id)
	const job = jobsData.find((job) => job.id === jobId)

	if (!job) {
		return (
			<div className="flex flex-col items-center justify-center h-[70vh]">
				<h1 className="text-2xl font-bold mb-4">Job not found</h1>
				<p className="text-muted-foreground mb-6">
					The job you are looking for does not exist or has been removed.
				</p>
				<Button onClick={() => router.push("/dashboard/jobs")}>
					<ArrowLeft className="mr-2 h-4 w-4" />
					Back to Jobs
				</Button>
			</div>
		)
	}

	const formatDate = (dateString: string) => {
		return new Date(dateString).toLocaleDateString("en-US", {
			year: "numeric",
			month: "long",
			day: "numeric",
		})
	}

	const formatSalary = (salary: { min: number; max: number; currency: string }) => {
		return `${salary.currency} ${salary.min.toLocaleString()} - ${salary.max.toLocaleString()}`
	}

	return (
		<div className="space-y-6 max-w-5xl mx-auto px-4 sm:px-6">
			<div className="flex items-center justify-between">
				<Button
					variant="ghost"
					size="sm"
					onClick={() => router.push("/dashboard/jobs")}
				>
					<ArrowLeft className="mr-2 h-4 w-4" />
					Back to Jobs
				</Button>
				<Button
					onClick={() => router.push(`/dashboard/candidates?jobId=${jobId}`)}
					className="bg-primary text-primary-foreground hover:bg-primary/90"
				>
					<Users className="mr-2 h-4 w-4" />
					See All Candidates
				</Button>
			</div>

			<motion.div
				initial={{ opacity: 0, y: 20 }}
				animate={{ opacity: 1, y: 0 }}
				transition={{ duration: 0.5 }}
				className="space-y-6"
			>
				<Card className="border-border/60 shadow-sm overflow-hidden">
					<CardHeader className="bg-gradient-to-r from-primary/10 to-transparent pb-4">
						<div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
							<div>
								<CardTitle className="text-2xl">{job.title}</CardTitle>
								<CardDescription className="text-base">
									{job.department}
								</CardDescription>
							</div>
							<div className="flex flex-wrap gap-2">
								<Badge
									variant={job.status === "active" ? "default" : "secondary"}
								>
									{job.status === "active" ? "Active" : "Closed"}
								</Badge>
								<Badge variant="outline">
									{job.job_type === "full_time" ? "Full Time" : "Contract"}
								</Badge>
								{job.remote_allowed && (
									<Badge variant="outline" className="bg-green-50">
										Remote Allowed
									</Badge>
								)}
							</div>
						</div>
					</CardHeader>
					<CardContent className="p-6 space-y-6">
						<div className="grid grid-cols-1 md:grid-cols-2 gap-6">
							<div className="space-y-4">
								<div className="flex items-center gap-2 text-muted-foreground">
									<MapPin className="h-4 w-4" />
									<span>{job.location}</span>
								</div>
								<div className="flex items-center gap-2 text-muted-foreground">
									<DollarSign className="h-4 w-4" />
									<span>{formatSalary(job.salary_range)}</span>
								</div>
								<div className="flex items-center gap-2 text-muted-foreground">
									<Briefcase className="h-4 w-4" />
									<span>
										{job.experience_level.charAt(0).toUpperCase() +
											job.experience_level.slice(1)}{" "}
										Level
									</span>
								</div>
							</div>
							<div className="space-y-4">
								<div className="flex items-center gap-2 text-muted-foreground">
									<Calendar className="h-4 w-4" />
									<span>Apply by {formatDate(job.application_deadline)}</span>
								</div>
								<div className="flex items-center gap-2 text-muted-foreground">
									<Users className="h-4 w-4" />
									<span>{job.application_count} applications</span>
								</div>
								<div className="flex items-center gap-2 text-muted-foreground">
									<Clock className="h-4 w-4" />
									<span>{job.view_count} views</span>
								</div>
							</div>
						</div>

						<Separator />

						<div className="space-y-4">
							<h3 className="text-lg font-semibold">Job Description</h3>
							<p className="text-muted-foreground">{job.description}</p>
						</div>

						<div className="space-y-4">
							<h3 className="text-lg font-semibold">Requirements</h3>
							<ul className="list-disc pl-5 space-y-2 text-muted-foreground">
								{job.requirements.map((requirement, index) => (
									<li key={index}>{requirement}</li>
								))}
							</ul>
						</div>

						<Separator />

						<div className="flex flex-col sm:flex-row gap-4 pt-4">
							<Button className="flex-1" size="lg" variant="outline">
								<PencilIcon className="mr-2 h-4 w-4" />
								Edit Job Post
							</Button>
							<Button variant="destructive" className="flex-1" size="lg">
								<Trash2Icon className="mr-2 h-4 w-4" />
								Delete Job Post
							</Button>
							<Button
								className="flex-1"
								size="lg"
								onClick={() => router.push(`/dashboard/candidates?jobId=${jobId}`)}
							>
								<Users className="mr-2 h-4 w-4" />
								View Applications
							</Button>
						</div>
					</CardContent>
				</Card>
			</motion.div>
		</div>
	)
}
