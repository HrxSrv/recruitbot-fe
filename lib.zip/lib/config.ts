export const baseUrl = process.env.NEXT_PUBLIC_API_BASE_URL ?? 'http://localhost:8000'
export const googleClientId = process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID ?? '888884451068-qj86re7vb9m9kp9a0s6d5oh4pmj256mk.apps.googleusercontent.com'
 