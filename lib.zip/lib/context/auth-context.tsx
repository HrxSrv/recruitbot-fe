'use client'

import { createContext, useContext, useEffect, useState } from 'react'
import { googleAuth, validateAuth, logout, type AuthResponse } from '@/lib/api/auth'

interface User {
  id: string
  email: string
  name: string
  picture?: string
}

interface AuthContextType {
  user: User | null
  isLoading: boolean
  isAuthenticated: boolean
  loginWithGoogle: (response: { credential: string }) => Promise<void>
  logout: () => Promise<void>
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  isLoading: true,
  isAuthenticated: false,
  loginWithGoogle: async () => {},
  logout: async () => {},
})

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [initialized, setInitialized] = useState(false)

  // Check authentication status on mount
  useEffect(() => {
    let mounted = true

    const checkAuth = async () => {
      try {
        const response = await validateAuth()
        if (mounted) {
          setUser(response.user)
        }
      } catch (error) {
        // If validation fails, user is not authenticated
        if (mounted) {
          setUser(null)
        }
      } finally {
        if (mounted) {
          setIsLoading(false)
          setInitialized(true)
        }
      }
    }

    // Only check auth on initial load
    if (!initialized) {
      checkAuth()
    }

    return () => {
      mounted = false
    }
  }, [initialized]) // Only run when initialized changes

  const handleGoogleLogin = async (response: { credential: string }) => {
    try {
      setIsLoading(true)
      const authResponse = await googleAuth(response)
      setUser(authResponse.user)
    } catch (error) {
      console.error('Login failed:', error)
      throw error // Re-throw to handle in UI
    } finally {
      setIsLoading(false)
    }
  }

  const handleLogout = async () => {
    try {
      setIsLoading(true)
      await logout()
      // Clear all auth state
      setUser(null)
      setInitialized(false) // Allow re-initialization on next mount
      // Use Next.js router for client-side navigation
      window.location.replace('/login')
    } catch (error) {
      console.error('Logout failed:', error)
      // Even if logout fails on server, clear client state
      setUser(null)
      setInitialized(false)
      window.location.replace('/login')
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        isLoading,
        isAuthenticated: !!user,
        loginWithGoogle: handleGoogleLogin,
        logout: handleLogout,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => useContext(AuthContext)