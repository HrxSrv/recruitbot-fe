"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { motion } from "framer-motion"
import type { DashboardFunnel } from "@/lib/api/dashboard"

interface FunnelChartProps {
  funnel: DashboardFunnel
  isLoading?: boolean
}

export function FunnelChart({ funnel, isLoading }: FunnelChartProps) {
  const total = funnel.high + funnel.medium + funnel.low

  const funnelData = [
    {
      label: "High Priority",
      value: funnel.high,
      percentage: total > 0 ? (funnel.high / total) * 100 : 0,
      color: "bg-green-500",
      lightColor: "bg-green-100",
    },
    {
      label: "Medium Priority",
      value: funnel.medium,
      percentage: total > 0 ? (funnel.medium / total) * 100 : 0,
      color: "bg-yellow-500",
      lightColor: "bg-yellow-100",
    },
    {
      label: "Low Priority",
      value: funnel.low,
      percentage: total > 0 ? (funnel.low / total) * 100 : 0,
      color: "bg-red-500",
      lightColor: "bg-red-100",
    },
  ]

  if (isLoading) {
    return (
      <Card className="animate-pulse">
        <CardHeader>
          <div className="h-6 bg-gray-200 rounded w-32"></div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="space-y-2">
                <div className="flex justify-between">
                  <div className="h-4 bg-gray-200 rounded w-24"></div>
                  <div className="h-4 bg-gray-200 rounded w-12"></div>
                </div>
                <div className="h-6 bg-gray-200 rounded"></div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="border-gray-200">
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-gray-900">Application Priority Funnel</CardTitle>
        <p className="text-sm text-gray-500">Distribution of {total} total applications</p>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {funnelData.map((item, index) => (
            <motion.div
              key={item.label}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
              className="space-y-2"
            >
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <div className={`w-3 h-3 rounded-full ${item.color}`}></div>
                  <span className="text-sm font-medium text-gray-700">{item.label}</span>
                </div>
                <div className="text-right">
                  <span className="text-sm font-semibold text-gray-900">{item.value}</span>
                  <span className="text-xs text-gray-500 ml-1">({item.percentage.toFixed(1)}%)</span>
                </div>
              </div>

              {/* Animated progress bar */}
              <div className={`h-2 rounded-full ${item.lightColor} overflow-hidden`}>
                <motion.div
                  className={`h-full ${item.color} rounded-full`}
                  initial={{ width: 0 }}
                  animate={{ width: `${item.percentage}%` }}
                  transition={{ delay: index * 0.1 + 0.2, duration: 0.8 }}
                />
              </div>
            </motion.div>
          ))}

          {total === 0 && (
            <div className="text-center py-8 text-gray-500">
              <p>No applications data available</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
