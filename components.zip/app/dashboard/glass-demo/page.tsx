import GlassDemoPage from "../glass-demo"

export default function GlassDemo() {
  return <GlassDemoPage />
}
